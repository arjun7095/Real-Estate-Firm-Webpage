import React from "react";
import Login from "./Components/login";
import Nav from "./Components/nav";

function App(){
  return(
    <>   
     <Nav></Nav>
   
    </>

  );
}
export default App;